/*
Classe Jogadpr
 */
package quizzook;

import java.util.Scanner;

/**
 *
 * @author debora.goncalves
 */
public class Jogador extends Personagens{
    static Scanner input = new Scanner(System.in);
    private String nome;
    private String apelido;
    private String email;
    private String telefone;

    public Jogador(){        
      
    }

    public String getNome() {
        return nome;
    }

    public String getApelido() {
        return apelido;
    }
    
    public String getEmail() {
        return email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setNome() {        
        System.out.print("Informe o seu nome\n>>");;		
        this.nome = input.nextLine();
    }

    public void setApelido() {
        System.out.print("Informe seu apelido\n>> ");
        this.apelido = input.nextLine();
    }

    public void setEmail() {
        System.out.print("Informe seu email\n>> ");
        this.email = input.nextLine();
    }

    public void setTelefone() {
        System.out.print("Informe seu telefone\n>> ");
        this.telefone = input.nextLine();
    }

    public void Cadastro(){
        this.setNome();
        this.setApelido();
        this.setEmail();        
        this.setTelefone();
    }

    public void show(){
        System.out.println("<<show:>>\n"+"\nNome = "+
        this.getNome()+"\nApelido = "+ 
        this.getApelido()+"\nEmail = "+
        this.getEmail()+"\nTelefone = "+
        this.getTelefone());
    }
    
    
}
