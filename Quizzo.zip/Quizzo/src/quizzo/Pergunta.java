/*
    Classe Pergunta
 */
package quizzo;

import java.util.ArrayList;
import java.util.Scanner;

import javax.sound.sampled.SourceDataLine;

/**
 *
 * @author debora.goncalves
 */
public class Pergunta {
    static Scanner input = new Scanner(System.in);
    private Integer resposta1;
    private Integer resposta2;
    private Integer contador = 0;

    public ArrayList<String> nome;

    public Pergunta() {

    }

    public void setName(String nome1, String nome2) {
        nome.add(nome1);
        nome.add(nome2);
    }

    public Integer getResposta1() {
        return resposta1;
    }

    public Integer getContador() {
        return contador;
    }

    public void setResposta1(Integer resposta1) {
        this.resposta1 = resposta1;
    }

    public Integer getResposta2() {
        return resposta2;
    }

    public void setResposta2(Integer resposta2) {
        this.resposta2 = resposta2;
    }

    public void Perguntas(String nome1, String nome2) {
        String[] questoesPartida = {
                "Que codigo faz parte do bloco try? \n>>[Digite uma opção ou digite 'SAIR' para desistir]<<\n ",
                "Dado: int x[]; qual o valor de x?",
                "Qual palavra-chave usada para alocar memoria para um objeto recem-criado?",
                "Se voce precisasse fazer com que uma variavel especifica pertencesse a uma classe,"
                        + "e nao a uma instancia individual, que tipo de variavel usaria?" };

        String[][] opcoesPartida = { { "Qualquer codigo que tende a causar uma exceçao \n>>[Digite uma opção ou digite 'SAIR' para desistir]<<\n ",
                "Qualquer codigo capaz de tratar uma exceçao",
                "Qualquer codigo que tende a imprimir os detalhes da exceçao",
                "Qualquer codigo que esteja protegido contra uma exceçao" },

                { "1", "0", "nulo", "Algum numero aleatorio." },

                { "store", "memory", "new", "adress" },

                { "Uma variavel privada", "Uma variavel local", "Uma variavel publica", "Uma vari�vel estatica" } };

        String[] letras = { "{A} ", "{B} ", "{C} ", "{D} " };
        char[] respostaCerta = { 'A', 'C', 'C', 'D' };
        ArrayList<String> nome = new ArrayList<>();
        char resposta = ' ';
        nome.add(nome1);
        nome.add(nome2);
        int respostaPar = 0;
        int respostaImpar = 0;
        String vencedor = null;
        char escolhas = 'S';
        for (int i = 0, j = 0; i < questoesPartida.length; i++) {
            if (j > 1) {
                j = 0;
            }
            
            System.out.println("-------------------------------------------------");
            System.out.printf("vez de %s\n", nome.get(j));
            System.out.print(questoesPartida[i] + "\n");
            for (int k = 0; k < opcoesPartida[i].length; k++) {
                System.out.print(letras[k]);
                System.out.print(opcoesPartida[i][k] + "\n");
            }
            System.out.print("\n>>");
            resposta = input.next().toUpperCase().charAt(0);
            System.out.println("-------------------------------------------------");
            j++;

            if (resposta != "sair".toUpperCase().charAt(0)) {
                System.out.print("Tem certeza da sua resposta? Digite 'SIM para confirmar ou 'NAO' para mudar:\n>>");
                escolhas = input.next().toUpperCase().charAt(0);
                if (escolhas == "sim".toUpperCase().charAt(0)) {
                    if (resposta == respostaCerta[i]) {
                        System.out.println("-------------------------------------------------");
                        System.out.println("Voce acertou :)");
                        System.out.println("-------------------------------------------------");
                        if (j % 2 == 0) {
                            respostaPar++;
                        } else {
                            respostaImpar++;
                        }
                    } else {
                        System.out.println("-------------------------------------------------");
                        System.out
                                .println("Que pena voce errou, a resposta correta era a letra >> " + respostaCerta[i]);
                        System.out.println("-------------------------------------------------");
                    }
                } else {
                    System.out.println("okay");
                    Perguntas(nome1, nome2);
                }

                if (respostaImpar > respostaPar)
                    vencedor = nome.get(0);
                else if (respostaImpar < respostaPar) {
                    vencedor = nome.get(1);

                } else {
                    vencedor = "empate";
                }
            } else if (resposta == "sair".toUpperCase().charAt(0)) {
                System.out.println("Tem certeza que deseja desistir?\n>>");
                char escolha = input.next().toUpperCase().charAt(0);
                if (escolha == "sim".toUpperCase().charAt(0)) {
                    System.out.println("okay");
                    break;
                } else {
                    Perguntas(nome1, nome2);
                }

            }
        
        }
        resultado(nome, respostaImpar, respostaPar, vencedor);
    }

    public void resultado(ArrayList<String> nome, int respostaImpar, int respostaPar, String vencedor) {
        System.out.println("-------------------------------------------------");
        System.out.println("<<Pontuação final>>");
        System.out.println(nome.get(0) + " = " + respostaImpar);
        System.out.println(nome.get(1) + " = " + respostaPar);
        if (vencedor == null)
            System.out.println("Não teve vencedor");
        else if (vencedor == "empate") {
            System.out.println("Empatou");
        } else {

            System.out.println("O vencedor foi = " + vencedor);
        }
        System.out.println("-------------------------------------------------");
    }

}
