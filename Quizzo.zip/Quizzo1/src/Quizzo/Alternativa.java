/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Quizzo;

/**
 *
 * @author debora.goncalves
 */
public class Alternativa {
    
    public Alternativa(){
        
    }
    
    public void alternativas(int index){
        String[][] opcoesPartida = { 
                {"Qualquer codigo que tende a causar uma exceçao",
                "Qualquer codigo capaz de tratar uma exceçao",
                "Qualquer codigo que tende a imprimir os detalhes da exceçao",
                "Qualquer codigo que esteja protegido contra uma exceçao" },
            
                { "1", "0", "nulo", "Algum numero aleatorio." },
                { "store", "memory", "new", "adress" },
                { "Uma variavel privada", "Uma variavel local", "Uma variavel publica", "Uma vari�vel estatica" } ,
                {"Java","String","C#","JavaScript"},
                {"Classe, int e Objetos", "Classe, Metodos e Atributos", "Classe, String e Atributos", "Variável, Metodos e Atributos"},
                {"privada (private)","pacote (package)","protegida (protected)","estática (static)"},
                {"Encapsulamento","Agregação","Herança","Associação"},
                {"INSERT, SELECT, UPDATE, DESTROY","APPEND, SELECT, UPDATE, DELETE","APPEND, SELECT, CHANGE, DELETE","INSERT, SELECT, UPDATE, DELETE"},
                {"Programação Orientada a Ojetos","Programação Facilitada","Programação complexa","Programação em camadas"}};

                String[] letras = { "{A} ", "{B} ", "{C} ", "{D} " };

                for (int k = 0; k < opcoesPartida[index].length; k++) {
                    System.out.print(letras[k]);
                    System.out.print(opcoesPartida[index][k] + "\n");
                }
        
    }
}