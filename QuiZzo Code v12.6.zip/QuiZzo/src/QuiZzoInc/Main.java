package QuiZzoInc;

public class Main {

	public static void main(String[] args) {
		
		
		
		
		Quizzo quizzo = new Quizzo();
		quizzo.Janela();
		quizzo.MenuInicial();
		
		
		
		//if((quizzo.jogador1.getPersonagemEscolhido() != null) && (quizzo.jogador2.getPersonagemEscolhido() != null)) {
		//	quizzo.comecarJogo();
			
		//}
		
		//if(quizzo.cadJog.size() == 2) {
			//quizzo.menuDevs();
		//}
		
		
		
		
		
		
		
		
		/*CadastroJogador jogador1 = new CadastroJogador();
		CadastroJogador jogador2 = new CadastroJogador();
		quizzo.setoptMI();		
		if(quizzo.getOptMI() == 0) {
			
			jogador1.setNomeJogador();
			jogador2.setNomeJogador();
			
			jogador1.setPersonagemEscolhido(quizzo.EscolhaPersonagem());
			jogador2.setPersonagemEscolhido(quizzo.EscolhaPersonagem());
			Partida partida = new Partida(); 
		}
		else if(quizzo.getOptMI() == 1) {
			quizzo.MenuDevs();
		}
		else if(quizzo.getOptMI() == 1) {
			//quizzo.MenuRegras();
		}
		else if(quizzo.getOptMI() == 1) {
			//quizzo.MenuSair();
		}
		*/
		
		

	}

}
