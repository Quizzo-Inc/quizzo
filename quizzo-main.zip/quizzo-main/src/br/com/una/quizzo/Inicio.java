package br.com.una.quizzo;

public class Inicio {

	public static void main(String[] args) {
				
		// TODO Começar a implementação dentro dessa classe, já que ela é o main. 
		
		System.out.println("Olá mundo!");
	}

}
