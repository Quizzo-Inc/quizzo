package br.com.una.quizzo;

public class CadastroJogador {
	
	private int codigoJogador;

	public CadastroJogador(int codigoJogador) {
		super();
		this.codigoJogador = codigoJogador;
	}

	public int getCodigoJogador() {
		return codigoJogador;
	}

	public void setCodigoJogador(int codigoJogador) {
		this.codigoJogador = codigoJogador;
	}
	
	public void setJogadorId(int idJogador) { // TODO Implementar método
		
	}
	
	public void setNomeJogador(String nomeJogador) { // TODO Implementar método
		
	}
	
	public void setApelidoJogador(String apelidoJogador) { // TODO Implementar método
		
	}
	
	public void setopEmailJogador(String emailJogador) { // TODO Implementar método
		
	}
	
	public void setTelefoneJogador(String telefoneJogador) { // TODO Implementar método
		
	}
	
}
